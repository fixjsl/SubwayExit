using System.Net;
using UnityEngine;

public class Die : PlayerState
{
    public Die(PlayerStateMachine stateMachine) : base(stateMachine) { 
        canChanged = false;
    }
    public override void Enter()
    {
        player.animator.CrossFade(player.die, 0.001f);
        player.Rb.linearVelocity = Vector3.zero;
        player.GetComponent<PlayerStateMachine>().enabled = false;
        player.GetComponent<Collider>().enabled = false;
    }

    public override void Exit()
    {
        
    }





    public override void LogicUpdate()
    {
        //��Ȱ��ȭ
    }

    public override void PhysicalUpdate()
    {
        //��Ȱ��ȭ
    }
    public void ContinueGame()
    {
        canChanged = true;
    }
}
