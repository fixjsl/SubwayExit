using UnityEngine;

public class Interect : PlayerState
{


    public Interect(PlayerStateMachine stateMachine) : base(stateMachine) {
    
    }
    public override void Enter()
    {
        
    }

    public override void Exit()
    {
        
    }




    public override void LogicUpdate()
    {
        
    }

    public override void PhysicalUpdate()
    {
        
    }
}
