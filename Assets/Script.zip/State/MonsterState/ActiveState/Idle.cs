using MonsterStates;
using UnityEngine;

namespace MonsterStates
{
    public class idle : MonsterState
    {
        private TimeManager Timer = new TimeManager();
        private float changeTime;
        public idle(MonsterStateMachine monster) : base(monster)
        {
        }
        public override void Enter()
        {
            //idle�ִϸ��̼� ���
            changeTime = Random.Range(3, 5);
        }
        public override void Exit()
        {

        }

        public override void LogicUpdate()
        {
            if (Monster.status.detection_gauge >= 1f)
            {
                Monster.ChangeState<Chase>();
            }
            //3~5�ʵ� Move�� ��ȯ
            if (Timer.Timer(changeTime))
            {
                Monster.ChangeState<move>();
            }
        }
        public override void PhysicalUpdate()
        {
            
        }
    }
}

