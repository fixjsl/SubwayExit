using MonsterStates;
using UnityEngine;

namespace MonsterStates
{
    public class Return : MonsterState
    {
        public Return(MonsterStateMachine monster) : base(monster)
        {
        }
        public override void Enter()
        {
            base.Enter();
        }
        public override void Exit() {
            base.Exit();
        }
        public override void LogicUpdate()
        {
            base.LogicUpdate();
        }
        public override void PhysicalUpdate()
        {
            //�ڱ� ������������ ���ư�
            base.PhysicalUpdate();
        }
        public void EndReturn()
        {
            Monster.ChangeState<idle>();
        }
    }
}

