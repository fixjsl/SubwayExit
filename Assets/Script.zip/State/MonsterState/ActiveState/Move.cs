using UnityEngine;

namespace MonsterStates
{
    public class move : MonsterState
    {
        private TimeManager Timer = new TimeManager();
        private float changeTime;
        private float movebuffer;
        public move(MonsterStateMachine monster) : base(monster)
        {
            
        }
        public override void Enter()
        {
            Monster.animator.CrossFade(Monster.move, 0.01f);
            canChanged = false;
        }
        public override void Exit()
        {

        }

        public override void LogicUpdate()
        {
            if (Monster.status.detection_gauge >= 1f)
            {
                Monster.ChangeState<Chase>();
            }
            if (Timer.Timer(changeTime))
            {
                Monster.ChangeState<idle>();
            }
        }
        public override void PhysicalUpdate()
        {
            //3~5������ �����̴� idle���·� ���ư�
            
        }
    }
}

