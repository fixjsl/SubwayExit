using MonsterStates;
using System.Threading;
using UnityEngine;

namespace MonsterStates
{
public class Battle : MonsterState
{
    private TimeManager Timer = new TimeManager();
    private float delay;
    public Battle(MonsterStateMachine monster) : base(monster)
    {

    }
    public override void Enter()
    {
            Monster.animator.CrossFade("battle",0.01f);
            delay = Monster.status.atkdelay + Random.Range(-1, 1);
    }
    public override void Exit() { 

    }
    public override void LogicUpdate()
    {
        if (Timer.Timer(Monster.status.atkdelay))
        {
            Monster.ChangeState<Attack>();
        }
        //�÷��̾ �ٸ� �������� �Ѿ�� �������·� ��ȯ �� Return���·� ��ȯ

    }
    public override void PhysicalUpdate()
    {
        
    }
}
}

